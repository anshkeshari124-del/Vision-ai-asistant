plugins {
    id("com.android.application")
}
android {
    namespace = "com.vision.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vision.assistant"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
