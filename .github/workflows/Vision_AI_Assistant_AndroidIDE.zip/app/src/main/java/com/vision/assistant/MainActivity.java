package com.vision.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.AlphaAnimation;
import android.widget.*;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private final String[] features = {
        "AI Chat","Voice Assistant","Hindi & English","Phone Controller","App Controller",
        "Settings Controller","Coding Generator","AI Video Generator","AI Image Generator",
        "Logo Generator","Video Editing","Face Reference","Creative Face/Character Effects",
        "Song Tools","Effect Changer","Caption Changer","Caption Generator","Template Generator",
        "Wi-Fi Settings Shortcut","Game Generator","App Generator","Website Generator",
        "APK Build Guide","ZIP Generator","Call Assistant (manual)","SMS Reply Drafts",
        "Message Reply Assistant","Email Draft Assistant","App Lock Guidance","Private File Vault",
        "Voice Recognition","Text-to-Speech","Fingerprint-ready Lock","Cybersecurity Learning",
        "Smart Voice Commands","Bluetooth Settings Controller","Torch Shortcut","Coding Studio",
        "GitHub Public Project Explorer","Signature Generator","Copy Tools","Background Changer",
        "Creative Character Editor","Prank Call Simulator","Consent-based Location Sharing",
        "API Key Manager","HTML Generator","Online/Offline Mode","Homework Helper",
        "File Manager","Feature Switches","App Security Checks","ZIP Compress/Extract",
        "Video Editor Workspace","Voice Changer","Voice Management","Email Generator",
        "Test OTP Generator (mock only)","Test Phone Number Generator","Security Alerts",
        "App Store-style Catalog","AI Model Connector (API setup)"
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showSplash();
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(28,28,28,28);
        splash.setBackgroundColor(Color.rgb(9,10,35));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.vision_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(300,300);
        splash.addView(logo,imageLp);

        TextView name = new TextView(this);
        name.setText("VISION AI ASSISTANT");
        name.setTextColor(Color.WHITE);
        name.setTextSize(24);
        name.setTypeface(null,Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0,18,0,6);
        splash.addView(name);

        TextView tagline = new TextView(this);
        tagline.setText("Your AI • Your Tools • Your Ideas");
        tagline.setTextColor(Color.rgb(185,180,255));
        tagline.setGravity(Gravity.CENTER);
        splash.addView(tagline);

        ScaleAnimation pulse = new ScaleAnimation(0.88f,1.05f,0.88f,1.05f,
            Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
        pulse.setDuration(1100);
        pulse.setRepeatMode(Animation.REVERSE);
        pulse.setRepeatCount(Animation.INFINITE);
        logo.startAnimation(pulse);

        AlphaAnimation fade = new AlphaAnimation(0.35f,1f);
        fade.setDuration(1400);
        fade.setRepeatMode(Animation.REVERSE);
        fade.setRepeatCount(Animation.INFINITE);
        name.startAnimation(fade);

        setContentView(splash);
        logo.postDelayed(() -> {
            logo.clearAnimation();
            name.clearAnimation();
            showAuth();
        }, 2800);
    }

    private void showAuth() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24,24,24,24);
        root.setBackgroundColor(Color.rgb(12,18,32));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.vision_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(140,140);
        lpLogo.gravity=Gravity.CENTER;
        root.addView(logo,lpLogo);

        TextView title = new TextView(this);
        title.setText("Welcome to Vision AI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0,14,0,18);
        root.addView(title);

        EditText email = new EditText(this);
        email.setHint("Email address");
        email.setInputType( android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setTextColor(Color.WHITE);
        email.setHintTextColor(Color.LTGRAY);
        root.addView(email);

        EditText password = new EditText(this);
        password.setHint("Password");
        password.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
            android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setTextColor(Color.WHITE);
        password.setHintTextColor(Color.LTGRAY);
        root.addView(password);

        Button signUp = new Button(this);
        signUp.setText("Sign Up with Email");
        root.addView(signUp);
        signUp.setOnClickListener(v -> Toast.makeText(this,
            "Demo screen only: connect Firebase Authentication to create accounts.",
            Toast.LENGTH_LONG).show());

        Button login = new Button(this);
        login.setText("Log In");
        root.addView(login);
        login.setOnClickListener(v -> Toast.makeText(this,
            "Demo screen only: authentication service is not configured.",
            Toast.LENGTH_LONG).show());

        Button google = new Button(this);
        google.setText("Continue with Google");
        root.addView(google);
        google.setOnClickListener(v -> Toast.makeText(this,
            "Google Sign-In needs Firebase project setup.", Toast.LENGTH_LONG).show());

        TextView note = new TextView(this);
        note.setText("Sign-up is a UI preview. Configure a trusted authentication provider before release.");
        note.setTextColor(Color.LTGRAY);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0,12,0,12);
        root.addView(note);

        Button demo = new Button(this);
        demo.setText("Preview Feature Dashboard");
        root.addView(demo);
        demo.setOnClickListener(v -> showDashboard());
        setContentView(root);
    }

    private void showDashboard() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,16);
        root.setBackgroundColor(Color.rgb(12,18,32));

        TextView title = new TextView(this);
        title.setText("VISION AI ASSISTANT");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Your AI toolkit • Starter version");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0,8,0,18);
        root.addView(subtitle);

        EditText prompt = new EditText(this);
        prompt.setHint("Ask Vision AI… (demo interface)");
        prompt.setHintTextColor(Color.GRAY);
        prompt.setTextColor(Color.WHITE);
        root.addView(prompt);

        Button ask = new Button(this);
        ask.setText("Ask / Voice (demo)");
        root.addView(ask);
        ask.setOnClickListener(v -> Toast.makeText(this,
            prompt.getText().toString().trim().isEmpty() ? "Add a question first" :
            "Demo UI: connect a secure AI API to enable answers.", Toast.LENGTH_LONG).show());

        TextView section = new TextView(this);
        section.setText("FEATURE LIBRARY • 60");
        section.setTextColor(Color.rgb(100,190,255));
        section.setTypeface(null,Typeface.BOLD);
        section.setPadding(0,20,0,8);
        root.addView(section);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i=0;i<features.length;i++) {
            final String name = features[i];
            TextView item = new TextView(this);
            item.setText((i+1)+".  "+name+"   ›");
            item.setTextColor(Color.WHITE);
            item.setTextSize(16);
            item.setPadding(16,14,16,14);
            item.setBackgroundColor(Color.rgb(27,38,58));
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            itemLp.setMargins(0,0,0,8);
            list.addView(item,itemLp);
            item.setOnClickListener(v -> Toast.makeText(this,
                name+"\\nStarter placeholder — connect implementation/API as needed.",
                Toast.LENGTH_SHORT).show());
        }
        scroll.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(0,0,1));
        setContentView(root);
    }
}
