# Vision AI Assistant — Android Starter ZIP

यह AndroidIDE-compatible शुरुआती प्रोजेक्ट है (Java + Android Gradle Plugin).

## कैसे खोलें
1. ZIP extract करें।
2. AndroidIDE में `Vision_AI_Assistant` फोल्डर खोलें।
3. Gradle Sync होने दें।
4. Run ▶ दबाएँ।

## इसमें क्या है
- 60 फीचर्स का सूची/डैशबोर्ड UI
- Demo chat prompt
- Feature cards पर placeholder interaction
- Android manifest में basic permissions

## अभी क्या demo है
यह शुरुआती UI scaffold है, सभी 60 फीचर्स fully implemented नहीं हैं।
AI chat, image/video generation, API integrations, voice actions, file operations आदि को
अलग APIs, permissions, service implementations और testing से जोड़ना होगा।

## सुरक्षा
- API keys को APK में hardcode न करें। Production में secure backend/secret storage रखें।
- OTP केवल mock/testing data के लिए।
- Location sharing consent और Android permission से।
- Call/SMS/email automation को user review और system permissions के साथ रखें।
- Unauthorized hacking, tracking या security bypass functionality शामिल नहीं है।
- Copyright watermark/ownership हटाने के लिए tool नहीं है; licensed media workflows use करें।


## Splash Animation & Logo
- User-provided logo image included as `vision_logo.jpg`.
- Splash screen animates the logo with a pulsing scale and fades the app title.
- Splash is followed by a Sign Up / Login UI preview.
- Email and Google buttons are UI placeholders. Firebase/Auth provider configuration is required for real authentication.
